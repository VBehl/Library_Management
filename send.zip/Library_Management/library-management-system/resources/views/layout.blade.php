<!DOCTYPE html>
<html>
<head>
    <title>Library Management System</title>
</head>
<body>
    @yield('content')
</body>
</html>
